# Diabetes Prediction

• If you want to view the deployed model, then go to following links mention below:<br />
GitHub Repository: _https://github.com/anujvyas/Diabetes-Prediction-Deployment_<br />
Web App: _https://predicting-diabetes.herokuapp.com/_

• Please do ⭐ the repository, if it helped you in anyway.
